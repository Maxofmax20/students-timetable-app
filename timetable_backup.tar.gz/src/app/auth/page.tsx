'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type Mode = 'login' | 'register';

export default function AuthPage() {
  const [mode, setMode] = useState<Mode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError('');
    setLoading(true);

    const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(
        mode === 'login'
          ? { email, password }
          : {
              email,
              password,
              displayName: displayName || undefined
            }
      )
    });

    const data = await response.json();
    if (!response.ok || !data.ok) {
      setError(data?.message || 'تعذر إتمام العملية');
      setLoading(false);
      return;
    }

    router.push('/workspace');
    router.refresh();
  }

  return (
    <main className="auth-page">
      <section className="auth-card">
        <h1>{mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب'}</h1>
        <p>Login to switch from guest mode to real workspace data.</p>

        <form onSubmit={submit} className="auth-form">
          {mode === 'register' && (
            <label>
              الاسم
              <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </label>
          )}

          <label>
            البريد الإلكتروني
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>

          <label>
            كلمة المرور
            <input type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>

          {error && <div className="notice error">{error}</div>}

          <button className="btn" type="submit" disabled={loading}>
            {loading ? '...' : mode === 'login' ? 'دخول' : 'إنشاء الحساب'}
          </button>
        </form>

        <button className="link" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? 'ليس لديك حساب؟ أنشئ واحدًا' : 'لديك حساب؟ سجّل الدخول'}
        </button>
      </section>
    </main>
  );
}
